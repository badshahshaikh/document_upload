<head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" >
<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
</head>

<div class="container">
      <div class="row">
        <div class="col-md-12">


        <form id="add_user_form">

          <div class="form-group">  
            <label for="name">name:</label> 
            <input type="text" class="form-control" name="name" placeholder="Enter name" required="" 
            id="name">
          </div>


          <div class="form-group">  
            <label for="mobile">mobile:</label>
            <input type="text" class="form-control" name="mobile" placeholder="Enter Mobile" required="" 
            id="mobile">
          </div>

          <div class="form-group">
            <button type="submit" class="btn btn-primary" id="add_user">Add</button>
          </div>

        </form>

        </div>
      </div>
    </div>
       

<script>

    $(document).ready(function(){

        // Send OTP mobile jquery
        $("#add_user").on("click", function(e){ 
        e.preventDefault();    
        var name = $("#name").val();
        var mobile = $("#mobile").val();
        $.ajax({
            url  : "<?php echo base_url('signin/user_add_script') ?>",
            type : "POST",
            cache:false,
            data : {mobile:mobile,name:name},
            success:function(result){
                console.log(result);
                if ( result == '1' ) {
                    alert('user added successfully');
                    location.href = "<?php echo base_url('home/user_table') ?>";
                }     
            }
        });  
        });   

        });




</script>