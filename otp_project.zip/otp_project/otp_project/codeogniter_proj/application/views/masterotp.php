<head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" >
<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
</head>


    <div class="container">
      <div class="row">
        <div class="col-md-12">

          <form id="mobileForm">
            <div class="form-group">  
              <label for="mobile">Mobile:</label> 
              <input type="text" class="form-control" name="mobile" placeholder="Enter Mobile" required="" 
              id="mobile">
              <span class="error-message" style="color:red;"></span>
            </div>
            <div class="form-group">
              
              <button type="submit" class="btn btn-primary" id="sendOtp">Send OTP</button>
            </div>
          </form>

          <form id="otpForm" style="display:none;">
            <div class="form-group">  
              <label for="mobile">OTP:</label>
              <input type="number" size="6"  type="text" class="form-control" name="otp" placeholder="Enter OTP" required="" id="otp">
              <span class="otp-message" style="color: red;"></span>
            </div>
            <div class="form-group">
              <button type="submit" class="btn btn-success" id="verifyOtp">Verify OTP</button>
            </div>
          </form>
        </div>
      </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.js"></script> 
   
<script>

  function validate(phone) {

      var regex = /^[789]\d{9}$/;

      if (regex.test(phone)) {
          return true;
      } else {
          return false;
      }
      
  }

  function validate_otp(phone) {

      if (phone.length = 6 ) {
          return true;
      } else {
          return false;
      }

    }
 

    $(document).ready(function(){

        // Send OTP mobile jquery
        $("#sendOtp").on("click", function(e){
        e.preventDefault();
        var mobile = $("#mobile").val();
        if ( validate(mobile) ){
            $('.error-message').html("");
            $.ajax({
              url  : "<?php echo base_url('signin/send_sms_for_first_reg') ?>",
              type : "POST",
              cache:false,
              data : {mobile:mobile},
              success:function(result){
                  console.log(result);
              if ( result != '' ) {
                  $("#otpForm").show();
                  $("#mobileForm").hide();
                  alert('otp sent succesfully');
              }     
              }
          });  
        }else{
            console.log('not validate');
            $('.error-message').html("please put valid format");
        }

        });   

        // Verify OTP mobile jquery
        $("#verifyOtp").on("click",function(e){
          e.preventDefault();
          var otp = $("#otp").val();

          
          if ( validate_otp(otp) ){
              $.ajax({
                  url  : "<?php echo base_url('signin/verify_otp') ?>",
                  type : "POST",
                  cache:false,
                  data : {otp:otp},
                  success:function(response){
                  if (response != "") {
                      console.log(response);
                      location.href = "<?php echo base_url('home/user_table') ?>";
                  }
                  }
              });
            }else{
              console.log('not validate');
              $('.otp-message').html("please put valid format");
            }

          });


        });



</script>