<head>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css">
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
</head>

<div class="container">

    <div class="row">

        <div class="col-md-12">
  
            <a href="<?php echo base_url('home/admin_login') ?>" >
                <button type="button" class="btn btn-primary">Admin Login</button>
            </a>
            <a href="<?php echo base_url('home/user_login') ?>" >
                <button type="button" class="btn btn-primary">User login</button>
            </a>

        </div>

    </div>

</div>

