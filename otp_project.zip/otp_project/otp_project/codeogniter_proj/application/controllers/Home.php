<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */

	public function __construct() {
		parent::__construct();
		$this->load->helper('url');
	}

	public function index()
	{
        $this->load->view('index');
	}

	public function verify()
	{
        $this->load->view('verify');
	}

	public function master_otp()
	{
        $this->load->view('masterotp');
	}

	public function admin_login()
	{
		$this->load->view('admin_login');
	}

	public function user_table()
	{
		$query=$this->db->get("user_info");
		$result['data'] = $query->result();
		$this->load->view('user_table',$result);
	}

	public function add_user()
	{
		$this->load->view('add_user');
	}

	public function user_login()
	{
		$this->load->view('user_login');
	}

	public function document_table()
	{
		$query=$this->db->get("documents");
		$result['data'] = $query->result();
		$this->load->view('document_table',$result);
	}

	public function add_doc()
	{
		$this->load->view('add_doc');
	}

}
