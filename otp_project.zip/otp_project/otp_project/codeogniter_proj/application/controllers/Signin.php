<?php

class Signin extends CI_Controller {

public function __construct() {
    parent::__construct();
    $this->load->library('session');
    $this->load->model('Signin_model');
    $this->load->helper(array('form', 'url'));
}

public function sign_in() {
    $this->load->view('sign_in');	
}

public function login() {

    $mobile	= $this->input->post('mobile');

    // $user = $this->Signin_model->check_mobile($mobile);
    // echo  $this->db->last_query();
    // exit();
    if($mobile) {

        // Generate OTP
        $otp = $this->generate_otp();

        $data = [
            'otp'	=> $otp,
        ];

        // update otp in database
        // $this->Signin_model->update_otp($mobile, $data);

        // send otp on mobile number
        $message = $otp." is your OTP. Do not share with anyone.";
        echo $mobile . ' <br> ' .$message;
        // $this->send_sms($mobile, $message);
        $this->load->library('smsalert/smsalertlib');
        $sms = $this->smsalertlib->smssend($mobile, $message);
        if($sms){
            echo  "otp sent";
        }else{
            echo "sms not sent";
        }
        $data['mobile'] = $mobile;

        


    } else {
        echo "Invalid mobile number";
    }
}

public function otp() {
    //Your authentication key
    $authKey = "YourAuthKey";

    //Multiple mobiles numbers separated by comma
    $mobileNumber = "9999999";

    //Sender ID,While using route4 sender id should be 6 characters long.
    $senderId = "helsky";

    //Your message to send, Add URL encoding here.
    $message = urlencode("Test message");

    //Define route 
    $route = "default";
    //Prepare you post parameters
    $postData = array(
        'authkey' => $authKey,
        'mobiles' => $mobileNumber,
        'message' => $message,
        'sender' => $senderId,
        'route' => $route
    );

    //API URL
    $url="http://api.msg91.com/api/sendhttp.php";

    // init the resource
    $ch = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $postData
        //,CURLOPT_FOLLOWLOCATION => true
    ));


    //Ignore SSL certificate verification
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);


    //get response
    $output = curl_exec($ch);

    //Print error if any
    if(curl_errno($ch))
    {
        echo 'error:' . curl_error($ch);
    }

    curl_close($ch);

    echo $output;
}

public function send_sms($phone, $body) {

    // Your authentication key
    $authKey 	= 'auth_key';

    // Multiple mobiles numbers separated by comma					
    // Sender ID,While using route4 sender id should be 6 characters long.
    $senderId 	= 'CXSTEC';

    // Your message to send, Add URL encoding here.
    $message 	= urlencode($body);

    //Define route 
    $route 		= 'trans';

    //Prepare you post parameters
    $postData 	= array(
        'authkey' 	=> $authKey,
        'mobiles' 	=> $phone,
        'message' 	=> $message,
        'sender' 	=> $senderId,
        'route' 	=> $route
    );	

    //API URL
    $url 		= 'http://api.msg91.com/api/sendhttp.php';	

    $ch = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL 			=> $url,
        CURLOPT_RETURNTRANSFER		=> true,
        CURLOPT_POST 			=> true,
        CURLOPT_POSTFIELDS 		=> $postData
        ));		

    //Ignore SSL certificate verification
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

    //get response
    $output = curl_exec($ch);	
            
    curl_close($ch);
}

public function user_add_script()
{
    
    $name	= $this->input->post('name');
    $mobile	= $this->input->post('mobile');

    $data = array(
        'name'=>$name,
        'mobile'=>$mobile
    );

    $add_user_query = $this->db->insert('user_info',$data);

    if( $add_user_query ){
        echo '1';
    }else{
        echo '0';
    }

}

public function send_sms_for_first_reg(){

    // NOTE : only 8 credit left
    $mobile = $this->input->post('mobile'); 

    $otp = $this->generate_otp();
    $this->session->set_userdata('new_admin_reg_number', $mobile);
    $this->session->set_userdata('master_otp', $otp);
    echo $this->session->userdata('master_otp');
    // echo $this->session->userdata('new_admin_reg_number');
    exit();
	// Authorisation details.
	$username = "hello@skypathdigital.com";
	$hash = "889a8a57fc6294e7d25effefa4a9c307c0a396fbdb208cc15c7fdc0b761f7f7a";

	// Config variables. Consult http://api.textlocal.in/docs for more info.
	$test = "0";

	// Data for text message. This is the text message data.
	$sender = "600010"; // This is who the message appears to be from.
	$numbers = "917977185230"; // A single number or a comma-seperated list of numbers
	$message = ' Hi there, thank you for sending your first test message from Textlocal. Get 20% off today with our code: 222222. ';
	// 612 chars or less
	// A single number or a comma-seperated list of numbers
	$message = urlencode($message);
	$data = "username=".$username."&hash=".$hash."&message=".$message."&sender=".$sender."&numbers=".$numbers."&test=".$test;
	$ch = curl_init('http://api.textlocal.in/send/?');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$result = curl_exec($ch); // This is the result from the API
	curl_close($ch);
	echo($result); 

}

public function send_sms_for_login(){

    $mobile = $this->input->post('mobile');
    $this->session->set_userdata('admin_reg_number', $mobile);
    $sql="Select id from `admin_info` WHERE  number = ".$mobile;
    $query = $this->db->query($sql);

    if( $query->num_rows() > 0 ){

        $otp = $this->generate_otp();
        $this->session->set_userdata('master_login_otp', $otp);
        echo $this->session->userdata('master_login_otp');

    }else{

        echo 'not registered';

    }

}

public function generate_otp() {
    $OTP =	rand(1,9);
    $OTP .=	rand(0,9);
    $OTP .=	rand(0,9);
    $OTP .=	rand(0,9);
    $OTP .=	rand(0,9);
    $OTP .=	rand(0,9);
     return $OTP;
}

public function verify_otp() {

    $sms_otp = $this->session->userdata('master_otp');
    $otp = $this->input->post('otp');
    // $mobile = $this->input->post('mobile');
    echo $otp;
    $new_admin_mobile = $this->session->userdata('new_admin_reg_number');

    $data = array(
        'number'=>$new_admin_mobile
    );

    $query = $this->db->insert('admin_info',$data);

    if ( $query ) {
        echo 'inserted';
    }else{
        echo 'failed';
    } 

    exit();
    if( $otp == $sms_otp ){
        echo 'otp verified successfully';
    }else{
        echo 'otp did not match';
    }
    exit();

    $mobile	 = $this->input->post('mobile');
    

    // check for otp 
    $user = $this->Signin_model->verify($mobile, $otp);
    if($user) {
        $this->session->set_userdata($user);
        redirect('user/dashboard');
    } else {
        echo "Invalid OTP or Mobile number.";
    }
}

public function verify_registered_number_otp(){

    $new_admin_mobile = $this->session->userdata('admin_reg_number');
    $otp = $this->input->post('otp');
    $mlo = $this->session->userdata('master_login_otp');

    $sql="Select id from `admin_info` WHERE  number = ".$new_admin_mobile;
    $query = $this->db->query($sql);

    if( $query->num_rows() > 0 ){
        if( $otp == $mlo ){
            echo '1';
        }else{
            echo '0';
        }
    }else{
        echo 'mobile number not registered';
    }

    exit();

}

public function user_login(){

    $mobile = $this->input->post('mobile');
    $this->session->set_userdata('user_mobile', $mobile);
    $sql = "Select id from `user_info` WHERE  mobile = ".$mobile;
    
    
    $query = $this->db->query($sql);

    if( $query->num_rows() > 0 ){
        // echo '1';
        $otp = $this->generate_otp();
        $this->session->set_userdata('user_login_otp', $otp);
        echo $this->session->userdata('user_login_otp');

    }else{
        echo '0';
    }

}

public function verfy_user_login(){

    $user_mobile = $this->session->userdata('user_mobile');
    $otp = $this->input->post('otp');
    $mlo = $this->session->userdata('user_login_otp');

    $sql="Select id from `admin_info` WHERE  number = ".$user_mobile;
    $query = $this->db->query($sql);

    if( $query->num_rows() > 0 ){
        if( $otp == $mlo ){
            echo '1';
        }else{
            echo '0';
        }
    }else{
        echo 'mobile number not registered';
    }

}


public function upload_doc_script(){

    if(isset($_POST["add_user"])){

        $new_file_name = time()."-".str_replace(' ','-',$_FILES["filename"]["name"]);
        $config['upload_path']          = './upload/';
        $config['allowed_types']        = 'gif|jpg|png|pdf';
        $config['max_size']             = 10000;
        $config['max_width']            = 1024;
        $config['max_height']           = 768;
        $config['file_name']           = $new_file_name;


        $this->load->library('upload', $config);

        if ( ! $this->upload->do_upload('filename'))
        {
                print_r($this->upload->display_errors());
        }
        else
        {
                print_r($this->upload->data());
                $data = array(
                    'file_name'=>$new_file_name
                );
            
                $add_user_query = $this->db->insert('documents',$data);
                if( $add_user_query ){
                    redirect('Home/document_table', 'refresh');
                }
                
        }


        exit();

        }

}


}


?>